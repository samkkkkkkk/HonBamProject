import './App.css';
import MainPage from './Component/MainPage';
import SnsBoard from './Component/SnsBoard';
import MyDetail from './Component/MyDetail';
import UserDetail from './Component/UserDetail';
import UserDetail2 from './Component/UserDetail2';

function App() {
  return (
    <>
      <div>
        {/* <MainPage /> */}
        {/* <SnsBoard /> */}
        {/* <MyDetail /> */}
        <UserDetail />
        <UserDetail2 />
      </div>
    </>
  );
}

export default App;
